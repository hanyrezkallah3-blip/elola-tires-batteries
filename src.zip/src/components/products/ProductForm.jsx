import {
  useCallback,
  useState
} from 'react'

import ProductBasicInfo
  from './form/ProductBasicInfo'

import ProductPricing
  from './form/ProductPricing'

import ProductInventory
  from './form/ProductInventory'

import ProductTireFields
  from './form/ProductTireFields'

import ProductBatteryFields
  from './form/ProductBatteryFields'

import ProductOilFields
  from './form/ProductOilFields'

import ProductImageUpload
  from './form/ProductImageUpload'

import { useInventoryStore } from '../../store/inventoryStore'  


const INITIAL_PRODUCT = {

  name: '',

  type: 'tire',

  brand: '',

  model: '',


  purchasePrice: 0,

  salePrice: 0,

  discountPrice: 0,

  cost: 0,


  quantity: 0,

  warehouseId: '',

warehouseName: '',

  minimumStock: 0,

  maximumStock: 0,

  reorderPoint: 0,


  tire: {

    width: '',

    height: '',

    rim: '',

    loadIndex: '',

    speedRating: '',

    season: ''

  },


  battery: {

    capacity: '',

    cca: '',

    voltage: '',

    polarity: '',

    length: '',

    width: '',

    height: ''

  },


  oil: {

    viscosity: '',

    api: '',

    acea: '',

    volume: ''

  },


  compatibleVehicles: [],

  compatibleSizes: [],


  image: '',

  images: [],


  active: true,

  createdAt: ''

}


export default function ProductForm({

  onAddProduct

}) {


  const [form,setForm] =

    useState(INITIAL_PRODUCT)

  const warehouses =
  useInventoryStore(
    state => state.warehouses || []
  ) 
  
  console.log('WAREHOUSES', warehouses)



  const submit = useCallback(()=>{


    if(
      !form.name.trim()
    ){

      alert(
        'اسم المنتج مطلوب'
      )

      return

    }


    if(
      Number(form.salePrice) <= 0
    ){

      alert(
        'سعر البيع غير صحيح'
      )

      return

    }



    const product = {

      ...form,


      profit:

        Number(form.salePrice || 0)
        -
        Number(form.purchasePrice || 0),


      profitMargin:

        form.purchasePrice > 0

        ?

        (

          (

            form.salePrice -
            form.purchasePrice

          )

          /

          form.purchasePrice

        )

        * 100

        :

        0,


      createdAt:

        new Date()
        .toISOString()

    }



    onAddProduct(product)



    setForm(
      INITIAL_PRODUCT
    )


    alert(
      'تم إضافة المنتج بنجاح'
    )


  },[
    form,
    onAddProduct
  ])




  return (

    <div className="
      space-y-8
      mb-12
    ">


      <ProductBasicInfo

        form={form}

        setForm={setForm}

      />



      <ProductPricing

        form={form}

        setForm={setForm}

      />



      <ProductInventory

        form={form}

        setForm={setForm}

      />

      <div className="bg-slate-900 rounded-3xl p-6">

  <label className="block mb-3 font-black">

    المخزن

  </label>

  <select

  value={form.warehouseId}

  onChange={(e) => {

    const warehouse =

      warehouses.find(

        (w) => String(w.id) === String(e.target.value)

      )

    setForm({

      ...form,

      warehouseId: e.target.value,

      warehouseName: warehouse?.name || ''

    })

  }}

  className="w-full p-4 rounded-2xl text-black"

>

  <option value="">

    اختر المخزن

  </option>

  {

    warehouses.map((warehouse, index) => (

      <option

        key={warehouse.id || index}

        value={warehouse.id || ''}

      >

        {warehouse.name} - {warehouse.location}

      </option>

    ))

  }

</select>

</div>



      <ProductTireFields

        form={form}

        setForm={setForm}

      />



      <ProductBatteryFields

        form={form}

        setForm={setForm}

      />



      <ProductOilFields

        form={form}

        setForm={setForm}

      />



      <ProductImageUpload

        form={form}

        setForm={setForm}

      />




      <button

        type="button"

        onClick={submit}

        className="
          w-full
          bg-yellow-500
          hover:bg-yellow-600
          text-black
          py-5
          rounded-3xl
          text-2xl
          font-black
          shadow-xl
        "

      >

        ➕ إضافة المنتج

      </button>


    </div>

  )

}