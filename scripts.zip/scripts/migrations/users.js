import fs from 'fs'

import { filterFiles } from '../core/fileFilter.js'

import { transformUseUserStore }
  from '../transforms/users/useUserStore.js'

export function usersMigration(files) {

  const keywords = [

    'useWebsiteStore',

    'users',

    'currentUser',

    'login',

    'logout',

    'register',

    'permissions',

    'setCurrentUser',

    'logoutUser'

  ]

  const targets = filterFiles(

    files,

    keywords

  )

  console.log('')
  console.log('====================================')
  console.log(' Users Migration')
  console.log('====================================')
  console.log('')

  let changed = 0

  for (const file of targets) {

    console.log('CHECKING:', file)

    const result = transformUseUserStore(file)

    if (result.changed) {

      fs.writeFileSync(

        file,

        result.code,

        'utf8'

      )

      changed++

      console.log('UPDATED:', file)

    }

  }

  console.log('')
  console.log('Changed:', changed)

}