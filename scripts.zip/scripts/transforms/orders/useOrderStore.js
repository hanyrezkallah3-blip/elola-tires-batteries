import { parseFile, visit, printAST } from '../../core/ast.js'

export function transformUseOrderStore(file) {

  const { ast, source } = parseFile(file)

  let changed = false

  visit(ast, {

    CallExpression(path) {

      const node = path.node

      if (

        node.callee?.type === 'Identifier' &&
        node.callee.name === 'useWebsiteStore' &&
        node.arguments.length === 1

      ) {

        const arg = node.arguments[0]

        if (

          arg.type === 'ArrowFunctionExpression' &&
          arg.body?.type === 'MemberExpression' &&
          arg.body.property?.name === 'orders'

        ) {

          node.callee.name = 'useOrderStore'
          changed = true

        }

      }

    }

  })

  return {

    changed,

    code: changed
      ? printAST(ast)
      : source

  }

}