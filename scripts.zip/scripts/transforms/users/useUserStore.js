import * as t from '@babel/types'
import { parseFile, visit, printAST } from '../../core/ast.js'

export function transformUseUserStore(file) {

  const { ast, source } = parseFile(file)

  let changed = false
  let hasUserImport = false
  let websiteImport = null

  visit(ast, {

    ImportDeclaration(path) {

      const value = path.node.source.value

      if (value.endsWith('/store/userStore')) {
        hasUserImport = true
      }

      if (value.endsWith('/store/websiteStore')) {
        websiteImport = path
      }

    },

    CallExpression(path) {

      const node = path.node

      if (
        node.callee?.type !== 'Identifier' ||
        node.callee.name !== 'useWebsiteStore'
      ) {
        return
      }

      if (node.arguments.length !== 1) {
        return
      }

      const arg = node.arguments[0]

      if (
        arg.type !== 'ArrowFunctionExpression' ||
        arg.body?.type !== 'MemberExpression'
      ) {
        return
      }

      const property = arg.body.property?.name

      const userFields = [

        'users',
        'currentUser',
        'login',
        'logout',
        'register',
        'permissions',
        'setCurrentUser',
        'logoutUser'

      ]

      if (!userFields.includes(property)) {
        return
      }

      node.callee.name = 'useUserStore'
      changed = true

    }

  })

  if (!changed) {

    return {
      changed: false,
      code: source
    }

  }

  if (!hasUserImport) {

    let importPath = '../store/userStore'

    if (file.endsWith('App.jsx')) {
      importPath = './store/userStore'
    }

    ast.program.body.unshift(

      t.importDeclaration(

        [

          t.importSpecifier(

            t.identifier('useUserStore'),

            t.identifier('useUserStore')

          )

        ],

        t.stringLiteral(importPath)

      )

    )

  }

  if (websiteImport) {

    const stillUsed = source.includes('useWebsiteStore(')

    if (!stillUsed) {

      websiteImport.remove()

    }

  }

  return {

    changed: true,

    code: printAST(ast)

  }

}