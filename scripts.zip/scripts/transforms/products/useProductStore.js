import { parseFile, printAST, visit } from '../../core/ast.js'

export function transformUseProductStore(file) {

  const { ast, source } = parseFile(file)

  let changed = false

  visit(ast, {

    CallExpression(path) {

      const node = path.node

      if (
        node.callee?.type !== 'Identifier' ||
        node.callee.name !== 'useWebsiteStore'
      ) {
        return
      }

      if (node.arguments.length !== 1) {
        return
      }

      const arg = node.arguments[0]

      if (
        arg.type !== 'ArrowFunctionExpression' ||
        arg.body?.type !== 'MemberExpression'
      ) {
        return
      }

      if (arg.body.property?.name !== 'products') {
        return
      }

      node.callee.name = 'useProductStore'

      changed = true

    }

  })

  return {

    changed,

    code: changed
      ? printAST(ast)
      : source

  }

}