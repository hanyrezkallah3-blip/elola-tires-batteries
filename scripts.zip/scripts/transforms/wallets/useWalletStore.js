import { parseFile, visit, printAST } from '../../core/ast.js'

export function transformUseWalletStore(file) {

  const { ast, source } = parseFile(file)

  let changed = false

  visit(ast, {

    CallExpression(path) {

      const node = path.node

      if (

        node.callee?.type === 'Identifier' &&
        node.callee.name === 'useWebsiteStore' &&
        node.arguments.length === 1

      ) {

        const arg = node.arguments[0]

        if (

          arg.type === 'ArrowFunctionExpression' &&
          arg.body?.type === 'MemberExpression'

        ) {

          const property = arg.body.property?.name

          if (

            property === 'wallets' ||
            property === 'walletTransactions' ||
            property === 'walletEnabled' ||
            property === 'cashbackPercentage'

          ) {

            node.callee.name = 'useWalletStore'
            changed = true

          }

        }

      }

    }

  })

  return {

    changed,

    code: changed
      ? printAST(ast)
      : source

  }

}