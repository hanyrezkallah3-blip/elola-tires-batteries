import { readFile } from './fileReader.js'

export function filterFiles(files, keywords = []) {

  return files.filter(file => {

    const content = readFile(file)

    return keywords.some(keyword =>

      content.includes(keyword)

    )

  })

}